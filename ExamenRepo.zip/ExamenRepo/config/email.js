// Configuración para la conexión con mailtrap
module.exports = {
  user: process.env.USERMAILTRAP,
  pass: process.env.PASSMAILTRAP,
  host: process.env.HOSTMAILTRAP,
  port: process.env.PORTMAILTRAP,
};
