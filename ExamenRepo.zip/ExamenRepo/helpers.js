exports.vardump = (object) => JSON.stringify(object, null, 2);
